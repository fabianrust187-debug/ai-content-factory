export const BRAND_PRESETS = {
  pets: {name:'Pfotenparadies Rust', handle:'@pfotenparadiesrust', kind:'Mobile Tierpflege', accent:'#d99472', secondary:'#96b5a1', tags:['#PfotenparadiesRust','#MobileTierpflege','#Hamburg','#Hundefriseur','#Hundeliebe']},
  gaming: {name:'Gaming Studio', handle:'@gaming', kind:'Gaming & Guides', accent:'#a69aff', secondary:'#70d4dc', tags:['#Gaming','#GamingDE','#GamingCommunity','#TippsUndTricks','#GamingClips']},
  other: {name:'Mein Projekt', handle:'@meinprojekt', kind:'Content Creator', accent:'#b49be9', secondary:'#d6a877', tags:['#Creator','#ReelsDeutsch','#ContentCreation','#Tipps','#Community']}
};
export function cleanText(v, fallback='') {return (String(v ?? '').replace(/[\u0000-\u001F\u007F]/g,' ').replace(/\s+/g,' ').trim().slice(0,1200)||fallback);}
export function trimWords(input,max=10) {const words=cleanText(input).split(' ');return words.length>max?words.slice(0,max).join(' ')+' …':words.join(' ');}
export function secToSrt(sec) {const m=Math.floor(sec/60),s=Math.floor(sec%60),ms=Math.floor((sec-Math.floor(sec))*1000);return `${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms).padStart(3,'0')}`;}
export function createSrt(scenes){return scenes.map((sc,i)=>`${i+1}\n${secToSrt(sc.start)} --> ${secToSrt(sc.end)}\n${sc.caption||sc.text||''}\n`).join('\n');}
export function slugify(v) {return cleanText(v).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,46)||'projekt';}
export function hashtags(tags){return [...new Set(tags)].join(' ')}
export function buildDrafts(input){
 const brand=BRAND_PRESETS[input.brand]||BRAND_PRESETS.other;
 const topic=cleanText(input.topic,'Ein Blick hinter die Kulissen');
 const audience=cleanText(input.audience,'unsere Community');
 const goal=cleanText(input.goal,'Aufmerksamkeit');
 const tone=cleanText(input.tone,'herzlich');
 const duration=Math.min(45,Math.max(15,Number(input.duration)||15));
 const times=[0, .24,.5,.76,1].map(f=>+(f*duration).toFixed(2));
 const preset=[
  {id:'a',label:'Aufmerksamkeit',badge:'Hook-first',title:`${trimWords(topic,7)} – schau genau hin`,hook:`Das solltest du über ${trimWords(topic,5)} wissen!`,beats:[`Heute geht es um ${trimWords(topic,7)}.`,`Wir zeigen dir, worauf es wirklich ankommt.`,`Ein kleiner Einblick, der viel erklärt.`],cta:'Speichere den Beitrag und folge uns für mehr!',action:'Du möchtest mehr sehen? Folge uns!'},
  {id:'b',label:'Mehrwert',badge:'Tipps & Wissen',title:`3 Gedanken zu ${trimWords(topic,6)}`,hook:`3 Dinge, die du bei ${trimWords(topic,5)} beachten kannst`,beats:[`Tipp 1: Starte mit einem klaren Ziel.`,`Tipp 2: Achte auf Details und Qualität.`,`Tipp 3: Nimm dir Zeit für das Ergebnis.`],cta:'Welcher Tipp hilft dir am meisten? Schreib es in die Kommentare!',action:'Welcher Tipp war neu für dich?'},
  {id:'c',label:'Persönlich',badge:'Behind the scenes',title:`Ein Einblick: ${trimWords(topic,6)}`,hook:`Komm mit – wir nehmen dich heute kurz mit!`,beats:[`Das ist unser Thema: ${trimWords(topic,7)}.`,`So gehen wir Schritt für Schritt vor.`,`Und genau deshalb machen wir das gern.`],cta:'Möchtest du mehr Einblicke? Dann folge unserem Profil!',action:'Mehr Einblicke gefällig?'}
 ];
 return preset.map(p=>{
  const scenes=[{start:times[0],end:times[1],caption:p.hook,kind:'Hook'},{start:times[1],end:times[2],caption:p.beats[0],kind:'Szene 1'},{start:times[2],end:times[3],caption:p.beats[1],kind:'Szene 2'},{start:times[3],end:times[4],caption:p.cta,kind:'Abschluss'}];
  const script=[p.hook,...p.beats,p.cta].join(' ');
  const postText=`${p.title}\n\n${p.hook}\n\n${p.beats.join('\n')}\n\n${p.action}\n\n${hashtags(brand.tags)}`;
  return {...p,duration,goal,tone,audience,brand:input.brand||'other',script,scenes,postText,platform:input.platform||'Instagram Reels'};
 });
}
export function normalizeAiDrafts(body,input){
 if(!Array.isArray(body?.drafts)||body.drafts.length<3) throw new Error('Unvollständige KI-Antwort');
 const fallback=buildDrafts(input);
 return body.drafts.slice(0,3).map((d,i)=>{
  const base=fallback[i];const safe=cleanText;
  const captions=Array.isArray(d.scenes)?d.scenes.map(s=>safe(typeof s==='string'?s:s.caption)).filter(Boolean).slice(0,6):[];
  const count=Math.max(2,captions.length);
  const scenes=(captions.length?captions:base.scenes.map(s=>s.caption)).map((caption,j,all)=>({start:+((j/all.length)*base.duration).toFixed(2),end:+(((j+1)/all.length)*base.duration).toFixed(2),caption,kind:j===0?'Hook':j===all.length-1?'Abschluss':`Szene ${j}`}));
  return {...base,title:safe(d.title,base.title),hook:safe(d.hook,base.hook),script:safe(d.script,base.script),postText:safe(d.postText,base.postText),scenes};
 });
}
