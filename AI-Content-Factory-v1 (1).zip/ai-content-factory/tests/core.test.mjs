import {test} from 'node:test';
import assert from 'node:assert/strict';
import {buildDrafts,createSrt,slugify,normalizeAiDrafts,secToSrt} from '../public/core.js';
const input={brand:'pets',topic:'Schonende Fellpflege bei Golden Retrievern',duration:30,platform:'Instagram Reels',tone:'Herzlich',goal:'Mehr Anfragen',audience:'Hundebesitzer Hamburg'};
test('three distinct drafts',()=>{const ds=buildDrafts(input);assert.equal(ds.length,3);assert.equal(new Set(ds.map(x=>x.hook)).size,3);for(const d of ds){assert.equal(d.scenes.length,4);assert.equal(d.scenes[3].end,30);assert.match(d.postText,/#PfotenparadiesRust/)}});
test('SRT in correct timing format',()=>{const ds=buildDrafts(input);const srt=createSrt(ds[0].scenes);assert.match(srt,/00:00:00,000 --> 00:00:07,200/);assert.match(srt,/00:00:22,800 --> 00:00:30,000/)});
test('SRT minutes rollover',()=>{assert.equal(secToSrt(65.25),'00:01:05,250')});
test('slugify handles umlauts and invalid symbols',()=>{assert.equal(slugify('Café & Hallo!'),'cafe-hallo')});
test('normalize AI captions and trim drafts',()=>{const fake={drafts:[1,2,3,4].map(i=>({title:`Num ${i}`,hook:`Hook ${i}`,script:'Hi',postText:'Test',scenes:['A','B','C','D']}))};const ds=normalizeAiDrafts(fake,input);assert.equal(ds.length,3);assert.equal(ds[0].scenes[0].start,0);assert.equal(ds[0].scenes[3].end,30)});
